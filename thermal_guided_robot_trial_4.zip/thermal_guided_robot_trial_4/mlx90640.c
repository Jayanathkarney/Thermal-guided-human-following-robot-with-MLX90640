// mlx90640.c
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "mlx90640.h"
#include "MLX90640_API.h"
#include "MLX90640_I2C_Driver.h"

extern void printstring(char *str);
extern void print_int(int val);

/* Shared 768-float scratch buffer — used by ExtractAlpha/Kta/Kv
   sequentially during init only. 3072 bytes, replaces 3x static arrays. */
float mlx_scratch[768];

/* frame calculation buffer — static to avoid stack allocation at runtime */
static float frameBuf[768];

static uint16_t      eeData[832];
static paramsMLX90640 mlxParams;
static uint16_t      rawFrame[834];




void mlx90640_init(void)
{
    int err;
    printstring(" step1: I2CInit...\r\n");
    MLX90640_I2CInit();
    printstring(" step1: done\r\n");

    printstring(" step2: DumpEE...\r\n");
    err = MLX90640_DumpEE(MLX90640_ADDR, eeData);
    printstring(" step2: rc="); print_int(err); printstring("\r\n");

    // ADD THIS — do not proceed with corrupted eeData
    if(err != 0) {
        printstring(" FATAL: EE read failed, check I2C wiring\r\n");
        while(1);   // halt here visibly rather than hanging in math
    }

    /* ADD THESE 3 LINES HERE */
        printstring(" eeData33="); print_int(eeData[33]); printstring("\r\n");
        printstring(" eeData48="); print_int(eeData[48]); printstring("\r\n");
        printstring(" eeData49="); print_int(eeData[49]); printstring("\r\n");

    printstring(" step3: ExtractParams...\r\n");
    err = MLX90640_ExtractParameters(eeData, &mlxParams);
    printstring(" step3: rc="); print_int(err); printstring("\r\n");

    printstring(" step4: SetRefresh...\r\n");
    err = MLX90640_SetRefreshRate(MLX90640_ADDR, 0x02);
    printstring(" step4: rc="); print_int(err); printstring("\r\n");

    printstring(" step5: SetChess...\r\n");
    err = MLX90640_SetChessMode(MLX90640_ADDR);
    printstring(" step5: rc="); print_int(err); printstring("\r\n");
}

int mlx90640_get_frame(float *dst)
{
    int status, i;
    float ta, tr;

    /* Initialize dst to a known bad value so we can detect unfilled pixels */
    for(i = 0; i < 768; i++) dst[i] = -999.0f;

    /* Subpage 0 */
    status = MLX90640_GetFrameData(MLX90640_ADDR, rawFrame);
    if(status < 0) return -1;
    ta = MLX90640_GetTa(rawFrame, &mlxParams);
    tr = ta - 8.0f;
    memset(frameBuf, 0, sizeof(frameBuf));
    MLX90640_CalculateTo(rawFrame, &mlxParams, 0.95f, tr, frameBuf);
    for(i = 0; i < 768; i++)
        if(frameBuf[i] != 0.0f) dst[i] = frameBuf[i];

    /* Subpage 1 */
    status = MLX90640_GetFrameData(MLX90640_ADDR, rawFrame);
    if(status < 0) return -1;
    ta = MLX90640_GetTa(rawFrame, &mlxParams);
    tr = ta - 8.0f;
    memset(frameBuf, 0, sizeof(frameBuf));
    MLX90640_CalculateTo(rawFrame, &mlxParams, 0.95f, tr, frameBuf);
    for(i = 0; i < 768; i++)
        if(frameBuf[i] != 0.0f) dst[i] = frameBuf[i];

    return 0;
}
