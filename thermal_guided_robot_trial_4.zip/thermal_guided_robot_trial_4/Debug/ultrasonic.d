# FIXED

ultrasonic.o: ../ultrasonic.c \
 C:/ti/TivaWare_C_Series-2.2.0.295/inc/tm4c123gh6pm.h

C:/ti/TivaWare_C_Series-2.2.0.295/inc/tm4c123gh6pm.h:
