# FIXED

main.o: ../main.c C:/ti/TivaWare_C_Series-2.2.0.295/inc/tm4c123gh6pm.h \
 ../mlx90640.h ../MLX90640_I2C_Driver.h ../MLX90640_API.h ../ultrasonic.h

C:/ti/TivaWare_C_Series-2.2.0.295/inc/tm4c123gh6pm.h:

../mlx90640.h:

../MLX90640_I2C_Driver.h:

../MLX90640_API.h:

../ultrasonic.h:
