# FIXED

servo.o: ../servo.c ../servo.h \
 C:/ti/TivaWare_C_Series-2.2.0.295/inc/tm4c123gh6pm.h

../servo.h:

C:/ti/TivaWare_C_Series-2.2.0.295/inc/tm4c123gh6pm.h:
