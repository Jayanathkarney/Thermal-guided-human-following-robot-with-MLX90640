# FIXED

mlx90640.o: ../mlx90640.c ../mlx90640.h ../MLX90640_API.h \
 ../MLX90640_I2C_Driver.h

../mlx90640.h:

../MLX90640_API.h:

../MLX90640_I2C_Driver.h:
