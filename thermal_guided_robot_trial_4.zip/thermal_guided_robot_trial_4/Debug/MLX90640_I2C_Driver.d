# FIXED

MLX90640_I2C_Driver.o: ../MLX90640_I2C_Driver.c ../MLX90640_I2C_Driver.h \
 ../MLX90640_API.h C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_memmap.h \
 C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_i2c.h \
 C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_types.h \
 C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/i2c.h \
 C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/sysctl.h \
 C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/gpio.h \
 C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/pin_map.h \
 C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_gpio.h

../MLX90640_I2C_Driver.h:

../MLX90640_API.h:

C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_memmap.h:

C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_i2c.h:

C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_types.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/i2c.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/sysctl.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/gpio.h:

C:/ti/TivaWare_C_Series-2.2.0.295/driverlib/pin_map.h:

C:/ti/TivaWare_C_Series-2.2.0.295/inc/hw_gpio.h:
