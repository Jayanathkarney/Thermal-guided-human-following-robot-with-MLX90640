# FIXED

model_inference.o: ../model_inference.c ../model_inference.h \
 ../model_weights.h

../model_inference.h:

../model_weights.h:
