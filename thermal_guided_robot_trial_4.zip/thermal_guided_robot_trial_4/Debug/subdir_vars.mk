################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
LDS_SRCS += \
../tm4c123gh6pm.lds 

C_SRCS += \
../MLX90640_API.c \
../MLX90640_I2C_Driver.c \
../main.c \
../mlx90640.c \
../tm4c123gh6pm_startup_ccs_gcc.c \
../uartstdio.c \
../ultrasonic.c 

C_DEPS += \
./MLX90640_API.d \
./MLX90640_I2C_Driver.d \
./main.d \
./mlx90640.d \
./tm4c123gh6pm_startup_ccs_gcc.d \
./uartstdio.d \
./ultrasonic.d 

OBJS += \
./MLX90640_API.o \
./MLX90640_I2C_Driver.o \
./main.o \
./mlx90640.o \
./tm4c123gh6pm_startup_ccs_gcc.o \
./uartstdio.o \
./ultrasonic.o 

OBJS__QUOTED += \
"MLX90640_API.o" \
"MLX90640_I2C_Driver.o" \
"main.o" \
"mlx90640.o" \
"tm4c123gh6pm_startup_ccs_gcc.o" \
"uartstdio.o" \
"ultrasonic.o" 

C_DEPS__QUOTED += \
"MLX90640_API.d" \
"MLX90640_I2C_Driver.d" \
"main.d" \
"mlx90640.d" \
"tm4c123gh6pm_startup_ccs_gcc.d" \
"uartstdio.d" \
"ultrasonic.d" 

C_SRCS__QUOTED += \
"../MLX90640_API.c" \
"../MLX90640_I2C_Driver.c" \
"../main.c" \
"../mlx90640.c" \
"../tm4c123gh6pm_startup_ccs_gcc.c" \
"../uartstdio.c" \
"../ultrasonic.c" 


