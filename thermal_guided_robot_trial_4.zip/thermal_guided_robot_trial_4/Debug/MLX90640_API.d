# FIXED

MLX90640_API.o: ../MLX90640_API.c \
 C:/Users/satis/workspace_v12/thermal_guided_robot_trial_4/MLX90640_I2C_Driver.h \
 C:/Users/satis/workspace_v12/thermal_guided_robot_trial_4/MLX90640_API.h \
 C:/Users/satis/workspace_v12/thermal_guided_robot_trial_4/MLX90640_API.h

C:/Users/satis/workspace_v12/thermal_guided_robot_trial_4/MLX90640_I2C_Driver.h:

C:/Users/satis/workspace_v12/thermal_guided_robot_trial_4/MLX90640_API.h:

C:/Users/satis/workspace_v12/thermal_guided_robot_trial_4/MLX90640_API.h:
