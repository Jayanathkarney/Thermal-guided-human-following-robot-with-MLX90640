// MLX90640_I2C_Driver.c — TM4C123 I2C1 implementation
// PA6=SDL, PA7=SCA (per TM4C123GH6PM datasheet)

#include <stdint.h>
#include <stdbool.h>
#include "MLX90640_I2C_Driver.h"
#include "inc/hw_memmap.h"
#include "inc/hw_i2c.h"
#include "inc/hw_types.h"
#include "driverlib/i2c.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "inc/hw_gpio.h"

#define I2C_BASE  I2C1_BASE

static uint8_t s_rxbuf[1664];

void MLX90640_I2CInit(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C1);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_I2C1));
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA));

    // TivaWare pin_map.h defines: PA6=SCL, PA7=SDA for I2C1
    GPIOPinConfigure(GPIO_PA6_I2C1SCL);
    GPIOPinConfigure(GPIO_PA7_I2C1SDA);
    GPIOPinTypeI2CSCL(GPIO_PORTA_BASE, GPIO_PIN_6);  // SCL
    GPIOPinTypeI2C   (GPIO_PORTA_BASE, GPIO_PIN_7);  // SDA

    I2CMasterInitExpClk(I2C_BASE, SysCtlClockGet(), false);  // false = 100kHz standard mode
    I2CMasterEnable(I2C_BASE);
}

static int i2c_wait(void)
{
    uint32_t timeout = 2000000;
    while (I2CMasterBusy(I2C_BASE)) {
        if (--timeout == 0) return -1;
    }
    if (I2CMasterErr(I2C_BASE) != I2C_MASTER_ERR_NONE) return -1;
    return 0;
}

int MLX90640_I2CRead(uint8_t slaveAddr, uint16_t startAddress,
                     uint16_t nMemAddressRead, uint16_t *data)
{
    uint8_t addrHi = (startAddress >> 8) & 0xFF;
    uint8_t addrLo =  startAddress       & 0xFF;
    uint32_t totalBytes = (uint32_t)nMemAddressRead * 2;
    uint32_t b;

    if(totalBytes > sizeof(s_rxbuf)) totalBytes = sizeof(s_rxbuf);

    /* Step 1: Send slave address + WRITE, no stop */
    I2CMasterSlaveAddrSet(I2C_BASE, slaveAddr, false);

    /* Step 2: Send register high byte — START */
    I2CMasterDataPut(I2C_BASE, addrHi);
    I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_BURST_SEND_START);
    if(i2c_wait()) return -1;

    /* Step 3: Send register low byte — CONT, no stop */
    I2CMasterDataPut(I2C_BASE, addrLo);
    I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_BURST_SEND_CONT);
    if(i2c_wait()) return -1;

    /* Step 4: Repeated START — switch to read mode */
    I2CMasterSlaveAddrSet(I2C_BASE, slaveAddr, true);

    /* Step 5: Burst read all bytes */
    I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_BURST_RECEIVE_START);
    if(i2c_wait()) return -1;
    s_rxbuf[0] = (uint8_t)I2CMasterDataGet(I2C_BASE);

    for(b = 1; b < totalBytes - 1; b++)
    {
        I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_BURST_RECEIVE_CONT);
        if(i2c_wait()) return -1;
        s_rxbuf[b] = (uint8_t)I2CMasterDataGet(I2C_BASE);
    }

    I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);
    if(i2c_wait()) return -1;
    s_rxbuf[totalBytes - 1] = (uint8_t)I2CMasterDataGet(I2C_BASE);

    for(uint16_t i = 0; i < nMemAddressRead; i++)
        data[i] = ((uint16_t)s_rxbuf[i*2] << 8) | s_rxbuf[i*2 + 1];

    return 0;
}

int MLX90640_I2CWrite(uint8_t slaveAddr, uint16_t writeAddress, uint16_t data)
{
    uint8_t addrHi = (writeAddress >> 8) & 0xFF;
    uint8_t addrLo =  writeAddress       & 0xFF;
    uint8_t dataHi = (data >> 8) & 0xFF;
    uint8_t dataLo =  data       & 0xFF;

    I2CMasterSlaveAddrSet(I2C_BASE, slaveAddr, false);

    I2CMasterDataPut(I2C_BASE, addrHi);
    I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_BURST_SEND_START);
    if (i2c_wait()) return -1;

    I2CMasterDataPut(I2C_BASE, addrLo);
    I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_BURST_SEND_CONT);
    if (i2c_wait()) return -1;

    I2CMasterDataPut(I2C_BASE, dataHi);
    I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_BURST_SEND_CONT);
    if (i2c_wait()) return -1;

    I2CMasterDataPut(I2C_BASE, dataLo);
    I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_BURST_SEND_FINISH);
    if (i2c_wait()) return -1;

    return 0;
}

int MLX90640_I2CGeneralReset(void)
{
    I2CMasterSlaveAddrSet(I2C_BASE, 0x00, false);
    I2CMasterDataPut(I2C_BASE, 0x06);
    I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_SINGLE_SEND);
    return i2c_wait() ? -1 : 0;
}

void MLX90640_I2CFreqSet(int freq)
{
    (void)freq;
}


void i2c_scan(void)
{
    extern void UART0_Transmitter(unsigned char data);
    extern void printstring(char *str);
    uint8_t addr;

    printstring("Scanning I2C...\r\n");

    for(addr = 0x08; addr < 0x78; addr++)
    {
        I2CMasterSlaveAddrSet(I2C_BASE, addr, false);
        I2CMasterDataPut(I2C_BASE, 0x00);
        I2CMasterControl(I2C_BASE, I2C_MASTER_CMD_SINGLE_SEND);

        volatile uint32_t t = 100000;
        while(I2CMasterBusy(I2C_BASE) && t--);

        if(I2CMasterErr(I2C_BASE) == I2C_MASTER_ERR_NONE)
        {
            printstring("Found: 0x");
            UART0_Transmitter("0123456789ABCDEF"[(addr >> 4) & 0xF]);
            UART0_Transmitter("0123456789ABCDEF"[addr & 0xF]);
            printstring("\r\n");
        }

        volatile uint32_t d = 10000;
        while(d--);
    }
    printstring("Scan done\r\n");
}
