#ifndef MLX90640_H
#define MLX90640_H

#include <stdint.h>

// MLX90640 I2C address
#define MLX90640_ADDR  0x33

// Call once in setup
void mlx90640_init(void);

// Get one frame � fills dst[768] with temperatures in Celsius
// Returns 0 on success, -1 on error
int mlx90640_get_frame(float *dst);

#endif
