#include <stdint.h>
#include "inc/tm4c123gh6pm.h"

void ultrasonic_init(void)
{
    /* PORTE: PE0=TRIG, PE1=ECHO */
    SYSCTL_RCGCGPIO_R |= 0x10;
    volatile int d = SYSCTL_RCGCGPIO_R; (void)d;
    GPIO_PORTE_AFSEL_R &= ~((1<<0)|(1<<1));
    GPIO_PORTE_AMSEL_R &= ~((1<<0)|(1<<1));
    GPIO_PORTE_PCTL_R  &= ~0x000000FF;
    GPIO_PORTE_DIR_R   |=  (1<<0);
    GPIO_PORTE_DIR_R   &= ~(1<<1);
    GPIO_PORTE_DEN_R   |=  (1<<0)|(1<<1);
    GPIO_PORTE_DATA_R  &= ~(1<<0);

    /* Timer4 free running */
    SYSCTL_RCGCTIMER_R |= 0x10;
    volatile int d2 = SYSCTL_RCGCTIMER_R; (void)d2;
    TIMER4_CTL_R   = 0;
    TIMER4_CFG_R   = 0x00;
    TIMER4_TAMR_R  = 0x02;
    TIMER4_TAILR_R = 0xFFFFFFFF;
    TIMER4_CTL_R   = 0x01;
}

uint32_t ultrasonic_read(void)
{
    uint32_t t1, t2, elapsed;
    uint32_t timeout = 0;
    volatile uint32_t i;

    /* Flush */
    timeout = 0;
    while(GPIO_PORTE_DATA_R & (1<<1)){
        if(++timeout > 2400000) return 997;
    }

    /* Trigger on PE0 */
    GPIO_PORTE_DATA_R &= ~(1<<0);
    for(i = 0; i < 267; i++);
    GPIO_PORTE_DATA_R |=  (1<<0);
    for(i = 0; i < 267; i++);
    GPIO_PORTE_DATA_R &= ~(1<<0);
    for(i = 0; i < 267; i++);

    /* Wait ECHO HIGH on PE1 */
    timeout = 0;
    while(!(GPIO_PORTE_DATA_R & (1<<1))){
        if(++timeout > 2400000) return 999;
    }
    t1 = TIMER4_TAV_R;

    /* Wait ECHO LOW */
    timeout = 0;
    while(GPIO_PORTE_DATA_R & (1<<1)){
        if(++timeout > 20000000) return 998;
    }
    t2 = TIMER4_TAV_R;

    if(t1 >= t2)
        elapsed = t1 - t2;
    else
        elapsed = (0xFFFFFFFF - t2) + t1;

    if(elapsed > 18560000) return 0;
    return elapsed / 4640;
}
