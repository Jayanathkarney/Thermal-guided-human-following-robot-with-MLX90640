/*
 * Human-Following Robot - TM4C123GH6PM
 * PIXEL-COUNT DETECTION VERSION
 *
 * Detection logic:
 *   At each servo position, count pixels where temp > ambient + AMBIENT_MARGIN_C
 *   If count >= HUMAN_PIXEL_THRESHOLD → human present at that position
 *   Direction chosen = position with highest pixel count
 *   Tie between forward and side → prefer forward
 *
 * Hardware verified constants:
 *   FORWARD_DUTY   = 20000
 *   TURN_DUTY      = 12000  90deg in 300ms
 *   UTURN_SPIN_US  = 600000 180deg
 *
 * Verified pin map:
 *   PA2 = left  motor FORWARD
 *   PA3 = left  motor BACKWARD
 *   PA4 = right motor FORWARD
 *   PA5 = right motor BACKWARD
 */

#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include "mlx90640.h"
#include "MLX90640_I2C_Driver.h"
#include "ultrasonic.h"

/* =========================================================
 *  PARAMETERS
 * ========================================================= */
#define FORWARD_STEP_US           50000
#define FORWARD_STEPS                40  /* 40 x 50ms = 2 seconds           */

#define TURN_TIME_LEFT_US         300000
#define TURN_TIME_RIGHT_US        300000
#define UTURN_SPIN_US             600000
#define SCAN_SETTLE_US            300000
#define CALIB_FRAMES                   10

#define OBSTACLE_STOP_DIST_CM         35
#define HUMAN_WAIT_DIST_CM            40
#define WAIT_TIMEOUT_CYCLES           25

/*
 * HUMAN_PIXEL_THRESHOLD:
 *   Minimum number of pixels that must exceed ambient+AMBIENT_MARGIN_C
 *   for that servo position to count as "human detected".
 *   MLX90640 = 768 pixels (32x24).
 *   A human torso at 1-2m fills roughly 80-150 pixels.
 *   70 is conservative enough to reject hot walls/lamps
 *   but reliable enough to catch a person standing to the side.
 *   Lower this if human is far away and misses detection.
 *   Raise this if getting false positives from warm objects.
 */
#define HUMAN_PIXEL_THRESHOLD         70

/*
 * AMBIENT_MARGIN_C:
 *   A pixel must exceed ambient by at least this much to count.
 *   1.5°C is more selective than the old 1.0°C — reduces false
 *   positives from warm walls while still catching human skin.
 */
#define AMBIENT_MARGIN_C           1.5f

#define HIST_TEMP_MIN            (-10.0f)
#define HIST_TEMP_MAX             (70.0f)
#define HIST_BIN_SIZE              (0.5f)
#define HIST_BINS                    160
#define CALIB_PERCENTILE              20

#define PWM_LOAD                   25000
#define FORWARD_DUTY               20000
#define TURN_DUTY                  12000

#define SERVO_0_ON_US               600
#define SERVO_0_OFF_US            19400
#define SERVO_90_ON_US             1500
#define SERVO_90_OFF_US           18500
#define SERVO_180_ON_US            2400
#define SERVO_180_OFF_US          17600
#define SERVO_CYCLES                  50

#define PA2  0x04
#define PA3  0x08
#define PA4  0x10
#define PA5  0x20
#define PB6  0x40
#define PB7  0x80

/* =========================================================
 *  STATE MACHINE
 * ========================================================= */
typedef enum {
    STATE_CALIBRATE,
    STATE_MOVE,
    STATE_SCAN,
    STATE_TURN,
    STATE_OBSTACLE_CHECK,
    STATE_WAIT_HUMAN,
    STATE_UTURN
} RobotState;

/* =========================================================
 *  GLOBALS
 * ========================================================= */
static float      frame[768];
static uint16_t   calib_hist[HIST_BINS];
static float      ambient_temp = 25.0f;
static RobotState robot_state  = STATE_CALIBRATE;
static int        chosen_dir   = 1;
static int        search_side  = 0;
static int        search_count = 0;
static int        wait_cycles  = 0;

/* =========================================================
 *  FORWARD DECLARATIONS
 * ========================================================= */
void     Delay_MicroSecond(int time);
void     Timer1_Init(void);
void     UART0_init(void);
void     UART0_Transmitter(unsigned char data);
void     printstring(char *str);
void     print_int(int val);
void     print_temp(float t);
void     print_uint(uint32_t val);
void     gpio_init(void);
void     pwm_init(void);
void     stop(void);
void     move_forward(void);
void     move_backward(void);
void     turn_left(void);
void     turn_right(void);
void     set_pwm_duty(uint32_t duty);
void     Servo_Position(int on_us, int off_us);
void     Servo_Right(void);
void     Servo_Forward(void);
void     Servo_Left(void);
uint32_t ultrasonic_read(void);
int      count_hot_pixels(void);
void     do_calibrate(void);
int      do_scan(void);
void     do_uturn(void);

/* =========================================================
 *  MAIN
 * ========================================================= */
int main(void)
{
    SYSCTL_RCC2_R  |=  0x80000000;
    SYSCTL_RCC2_R  |=  0x00000800;
    SYSCTL_RCC_R    = (SYSCTL_RCC_R & ~0x000007C0) | 0x00000540;
    SYSCTL_RCC2_R  &= ~0x00000070;
    SYSCTL_RCC2_R  &= ~0x00002000;
    SYSCTL_RCC2_R  |=  0x40000000;
    SYSCTL_RCC2_R   = (SYSCTL_RCC2_R & ~0x1FC00000) | (4 << 22);
    while((SYSCTL_RIS_R & 0x00000040) == 0);
    SYSCTL_RCC2_R  &= ~0x00000800;

    gpio_init();
    pwm_init();
    Timer1_Init();
    UART0_init();

    Delay_MicroSecond(100000);
    printstring("Robot Start\r\n");
    Delay_MicroSecond(500000);

    mlx90640_init();
    printstring("MLX ready\r\n");
    ultrasonic_init();
    printstring("Ultrasonic ready\r\n");

    while(1)
    {
        uint32_t dist;
        int i;

        switch(robot_state)
        {
        /* ============================================================
         *  CALIBRATE — once only at startup
         * ============================================================ */
        case STATE_CALIBRATE:
            do_calibrate();
            search_side  = 0;
            search_count = 0;
            robot_state  = STATE_MOVE;
            break;

        /* ============================================================
         *  MOVE — 2 seconds forward, obstacle check every 50ms
         * ============================================================ */
        case STATE_MOVE:
        {
            int obstacle_hit = 0;

            printstring("Moving 2s\r\n");
            set_pwm_duty(FORWARD_DUTY);
            move_forward();

            for(i = 0; i < FORWARD_STEPS && !obstacle_hit; i++)
            {
                Delay_MicroSecond(FORWARD_STEP_US);
                dist = ultrasonic_read();
                printstring("D="); print_uint(dist); printstring("\r\n");

                if(dist != 0 && dist < OBSTACLE_STOP_DIST_CM) {
                    stop();
                    printstring("Obstacle\r\n");
                    obstacle_hit = 1;
                    robot_state  = STATE_OBSTACLE_CHECK;
                }
            }

            if(!obstacle_hit) {
                stop();
                robot_state = STATE_SCAN;
            }
            break;
        }

        /* ============================================================
         *  SCAN — sets chosen_dir, goes to TURN if human found
         * ============================================================ */
        case STATE_SCAN:
        {
            int found = do_scan();

            if(found) {
                search_count = 0;
                search_side  = 0;
                printstring("Found dir=");
                print_int(chosen_dir);
                printstring("\r\n");
                robot_state = STATE_TURN;
            } else {
                printstring("Searching\r\n");
                set_pwm_duty(TURN_DUTY);
                if(search_side == 0) turn_right();
                else                 turn_left();
                Delay_MicroSecond(TURN_TIME_RIGHT_US / 2);
                stop();
                Delay_MicroSecond(300000);

                search_count++;
                if(search_count >= 4) {
                    search_count = 0;
                    search_side  = 1 - search_side;
                }
            }
            break;
        }

        /* ============================================================
         *  TURN — rotate toward human then MOVE
         * ============================================================ */
        case STATE_TURN:
        {
            if(chosen_dir == 0) {
                printstring("Turn right\r\n");
                set_pwm_duty(TURN_DUTY);
                turn_right();
                Delay_MicroSecond(TURN_TIME_RIGHT_US);
                stop();
                Delay_MicroSecond(200000);
            } else if(chosen_dir == 2) {
                printstring("Turn left\r\n");
                set_pwm_duty(TURN_DUTY);
                turn_left();
                Delay_MicroSecond(TURN_TIME_LEFT_US);
                stop();
                Delay_MicroSecond(200000);
            } else {
                printstring("Straight\r\n");
            }
            robot_state = STATE_MOVE;
            break;
        }

        /* ============================================================
         *  OBSTACLE CHECK — pixel count decides human or wall
         * ============================================================ */
        case STATE_OBSTACLE_CHECK:
        {
            Delay_MicroSecond(200000);

            int hot = 0;
            if(mlx90640_get_frame(frame) == 0)
                hot = count_hot_pixels();

            printstring("Obs hot px="); print_int(hot); printstring("\r\n");

            if(hot >= HUMAN_PIXEL_THRESHOLD) {
                printstring("Human blocking\r\n");
                wait_cycles = 0;
                robot_state = STATE_WAIT_HUMAN;
            } else {
                printstring("Wall, uturn\r\n");
                robot_state = STATE_UTURN;
            }
            break;
        }

        /* ============================================================
         *  WAIT HUMAN
         * ============================================================ */
        case STATE_WAIT_HUMAN:
        {
            dist = ultrasonic_read();
            printstring("W dist="); print_uint(dist); printstring("\r\n");

            if(dist != 0 && dist >= HUMAN_WAIT_DIST_CM) {
                printstring("Clear\r\n");
                wait_cycles = 0;
                robot_state = STATE_SCAN;
            } else if(wait_cycles >= WAIT_TIMEOUT_CYCLES) {
                printstring("Timeout\r\n");
                wait_cycles = 0;
                robot_state = STATE_SCAN;
            } else {
                wait_cycles++;
                Delay_MicroSecond(200000);
            }
            break;
        }

        /* ============================================================
         *  UTURN
         * ============================================================ */
        case STATE_UTURN:
            do_uturn();
            robot_state = STATE_SCAN;
            break;

        default:
            robot_state = STATE_SCAN;
            break;
        }
    }
}

/* =========================================================
 *  TIMER1
 * ========================================================= */
void Timer1_Init(void)
{
    SYSCTL_RCGCTIMER_R |= 0x02;
    volatile int d = SYSCTL_RCGCTIMER_R; (void)d;
    TIMER1_CTL_R   = 0;
    TIMER1_CFG_R   = 0x04;
    TIMER1_TAMR_R  = 0x02;
    TIMER1_TAILR_R = 80 - 1;
    TIMER1_ICR_R   = 0x01;
}

void Delay_MicroSecond(int time)
{
    int i;
    TIMER1_CTL_R = 0;
    TIMER1_ICR_R = 0x01;
    TIMER1_CTL_R = 0x01;
    for(i = 0; i < time; i++){
        while((TIMER1_RIS_R & 0x01) == 0);
        TIMER1_ICR_R = 0x01;
    }
    TIMER1_CTL_R = 0;
}

/* =========================================================
 *  COUNT HOT PIXELS
 *  Returns number of pixels in frame[] above
 *  ambient_temp + AMBIENT_MARGIN_C
 *  Call only after a successful mlx90640_get_frame()
 * ========================================================= */
int count_hot_pixels(void)
{
    float threshold = ambient_temp + AMBIENT_MARGIN_C;
    int count = 0;
    int i;
    for(i = 0; i < 768; i++)
        if(frame[i] > threshold) count++;
    return count;
}

/* =========================================================
 *  SCAN
 *  Sweeps servo RIGHT(0) → FORWARD(1) → LEFT(2)
 *  Counts hot pixels at each position.
 *  chosen_dir = position with highest hot pixel count
 *               provided it meets HUMAN_PIXEL_THRESHOLD.
 *  Prefer FORWARD when forward count is within 20 pixels
 *  of the winning side — avoids unnecessary turns.
 *  Returns 1 if human found, 0 if not.
 * ========================================================= */
int do_scan(void)
{
    int cR = 0, cFwd = 0, cL = 0;

    printstring("Scanning\r\n");

    Servo_Right();
    Delay_MicroSecond(SCAN_SETTLE_US);
    if(mlx90640_get_frame(frame) == 0) cR = count_hot_pixels();

    Servo_Forward();
    Delay_MicroSecond(SCAN_SETTLE_US);
    if(mlx90640_get_frame(frame) == 0) cFwd = count_hot_pixels();

    Servo_Left();
    Delay_MicroSecond(SCAN_SETTLE_US);
    if(mlx90640_get_frame(frame) == 0) cL = count_hot_pixels();

    Servo_Forward();

    printstring("R="); print_int(cR);
    printstring(" F="); print_int(cFwd);
    printstring(" L="); print_int(cL);
    printstring("\r\n");

    /* check if any position meets the minimum pixel threshold */
    int anyFound = (cR   >= HUMAN_PIXEL_THRESHOLD) ||
                   (cFwd >= HUMAN_PIXEL_THRESHOLD) ||
                   (cL   >= HUMAN_PIXEL_THRESHOLD);

    if(!anyFound) return 0;

    /* find the direction with the highest hot pixel count */
    int best = 0;
    chosen_dir = 1;   /* default to straight */

    if(cFwd > best) { best = cFwd; chosen_dir = 1; }
    if(cR   > best) { best = cR;   chosen_dir = 0; }
    if(cL   > best) {               chosen_dir = 2; }

    /*
     * Forward preference tie-break:
     * If forward count is within 20 pixels of the winning side,
     * prefer going straight to avoid unnecessary turns.
     * 20 pixel margin is roughly 2.6% of total frame.
     */
    if(chosen_dir != 1 && cFwd >= HUMAN_PIXEL_THRESHOLD
       && (best - cFwd) <= 20)
    {
        chosen_dir = 1;
    }

    return 1;
}

/* =========================================================
 *  CALIBRATION — histogram 20th percentile
 * ========================================================= */
void do_calibrate(void)
{
    int f, p, b;
    int total_pixels = 0;
    int cumulative   = 0;
    int target;

    printstring("Calibrating\r\n");
    stop();
    Servo_Forward();
    Delay_MicroSecond(SCAN_SETTLE_US);

    for(b = 0; b < HIST_BINS; b++) calib_hist[b] = 0;

    for(f = 0; f < CALIB_FRAMES; f++)
    {
        Delay_MicroSecond(200000);
        if(mlx90640_get_frame(frame) != 0) {
            printstring("Frame err\r\n");
            continue;
        }
        for(p = 0; p < 768; p++) {
            float t = frame[p];
            if(t < HIST_TEMP_MIN) t = HIST_TEMP_MIN;
            if(t > HIST_TEMP_MAX) t = HIST_TEMP_MAX;
            b = (int)((t - HIST_TEMP_MIN) / HIST_BIN_SIZE);
            if(b < 0)          b = 0;
            if(b >= HIST_BINS) b = HIST_BINS - 1;
            calib_hist[b]++;
            total_pixels++;
        }
        printstring("F"); print_int(f+1); printstring("\r\n");
    }

    if(total_pixels == 0) {
        printstring("Calib fail\r\n");
        return;
    }

    target       = (CALIB_PERCENTILE * total_pixels) / 100;
    cumulative   = 0;
    ambient_temp = HIST_TEMP_MIN;

    for(b = 0; b < HIST_BINS; b++) {
        cumulative += calib_hist[b];
        if(cumulative >= target) {
            ambient_temp = HIST_TEMP_MIN + ((float)b + 0.5f) * HIST_BIN_SIZE;
            break;
        }
    }

    printstring("Amb="); print_temp(ambient_temp);
    printstring(" Thr="); print_temp(ambient_temp + AMBIENT_MARGIN_C);
    printstring("\r\n");
}

/* =========================================================
 *  UTURN
 * ========================================================= */
void do_uturn(void)
{
    set_pwm_duty(FORWARD_DUTY);
    move_backward();
    Delay_MicroSecond(300000);
    stop();
    Delay_MicroSecond(150000);

    set_pwm_duty(TURN_DUTY);
    turn_right();
    Delay_MicroSecond(UTURN_SPIN_US);
    stop();
    Delay_MicroSecond(200000);

    set_pwm_duty(FORWARD_DUTY);
    move_forward();
    Delay_MicroSecond(250000);
    stop();
    Delay_MicroSecond(200000);
}

/* =========================================================
 *  SERVO
 * ========================================================= */
void Servo_Position(int on_us, int off_us)
{
    int i;
    for(i = 0; i < SERVO_CYCLES; i++) {
        GPIO_PORTC_DATA_R |=  (1 << 4);
        Delay_MicroSecond(on_us);
        GPIO_PORTC_DATA_R &= ~(1 << 4);
        Delay_MicroSecond(off_us);
    }
}

void Servo_Right(void)   { Servo_Position(SERVO_0_ON_US,   SERVO_0_OFF_US);   }
void Servo_Forward(void) { Servo_Position(SERVO_90_ON_US,  SERVO_90_OFF_US);  }
void Servo_Left(void)    { Servo_Position(SERVO_180_ON_US, SERVO_180_OFF_US); }

/* =========================================================
 *  GPIO
 * ========================================================= */
void gpio_init(void)
{
    SYSCTL_RCGCGPIO_R |= 0x01;
    volatile int d = SYSCTL_RCGCGPIO_R; (void)d;
    GPIO_PORTA_DIR_R  |= (PA2|PA3|PA4|PA5);
    GPIO_PORTA_DEN_R  |= (PA2|PA3|PA4|PA5);
    GPIO_PORTA_DATA_R &= ~(PA2|PA3|PA4|PA5);

    SYSCTL_RCGCGPIO_R |= 0x04;
    volatile int d2 = SYSCTL_RCGCGPIO_R; (void)d2;
    GPIO_PORTC_DIR_R |= (1 << 4);
    GPIO_PORTC_DEN_R |= (1 << 4);
}

/* =========================================================
 *  PWM
 * ========================================================= */
void pwm_init(void)
{
    SYSCTL_RCGCPWM_R  |= 0x01;
    SYSCTL_RCGCGPIO_R |= 0x02;
    volatile int d = SYSCTL_RCGCGPIO_R; (void)d;

    SYSCTL_RCC_R = (SYSCTL_RCC_R & ~0x000E0000) | 0x000A0000;
    SYSCTL_RCC_R |= 0x00100000;

    GPIO_PORTB_AFSEL_R |=  (PB6|PB7);
    GPIO_PORTB_PCTL_R  &= ~0xFF000000;
    GPIO_PORTB_PCTL_R  |=  0x44000000;
    GPIO_PORTB_DEN_R   |=  (PB6|PB7);

    PWM0_0_CTL_R  = 0;
    PWM0_0_GENA_R = 0x0000008C;
    PWM0_0_GENB_R = 0x0000080C;
    PWM0_0_LOAD_R = PWM_LOAD - 1;
    PWM0_0_CMPA_R = FORWARD_DUTY;
    PWM0_0_CMPB_R = FORWARD_DUTY;
    PWM0_0_CTL_R  = 0x01;
    PWM0_ENABLE_R |= 0x03;
}

void set_pwm_duty(uint32_t duty)
{
    PWM0_0_CMPA_R = duty;
    PWM0_0_CMPB_R = duty;
}

/* =========================================================
 *  MOTOR — HARDWARE VERIFIED
 * ========================================================= */
void stop(void)         { GPIO_PORTA_DATA_R &= ~(PA2|PA3|PA4|PA5); }
void move_forward(void) { stop(); GPIO_PORTA_DATA_R |= (PA2|PA4); }
void move_backward(void){ stop(); GPIO_PORTA_DATA_R |= (PA3|PA5); }
void turn_left(void)    { stop(); GPIO_PORTA_DATA_R |= (PA3|PA4); }
void turn_right(void)   { stop(); GPIO_PORTA_DATA_R |= (PA2|PA5); }

/* =========================================================
 *  UART0
 * ========================================================= */
void UART0_init(void)
{
    SYSCTL_RCGCUART_R |= 0x01;
    SYSCTL_RCGCGPIO_R |= 0x01;
    volatile int d = SYSCTL_RCGCGPIO_R; (void)d;
    UART0_CTL_R  = 0;
    UART0_IBRD_R = 43;
    UART0_FBRD_R = 26;
    UART0_CC_R   = 0;
    UART0_LCRH_R = 0x60;
    UART0_CTL_R  = 0x301;
    GPIO_PORTA_DEN_R   |= 0x03;
    GPIO_PORTA_AFSEL_R |= 0x03;
    GPIO_PORTA_AMSEL_R  = 0;
    GPIO_PORTA_PCTL_R   = (GPIO_PORTA_PCTL_R & ~0x000000FF) | 0x00000011;
}

void UART0_Transmitter(unsigned char data)
{
    while((UART0_FR_R & (1<<5)) != 0);
    UART0_DR_R = data;
}

void printstring(char *str)
{
    while(*str) UART0_Transmitter(*(unsigned char *)str++);
}

void print_int(int val)
{
    char buf[12]; int i = 0;
    if(val < 0){ UART0_Transmitter('-'); val = -val; }
    if(val == 0){ UART0_Transmitter('0'); return; }
    while(val > 0){ buf[i++]='0'+(val%10); val/=10; }
    while(i > 0) UART0_Transmitter(buf[--i]);
}

void print_temp(float t)
{
    int neg=0;
    if(t<0.0f){neg=1;t=-t;}
    int whole=(int)t;
    int frac=(int)((t-(float)whole)*10.0f+0.5f);
    if(frac>=10){whole++;frac=0;}
    if(neg)UART0_Transmitter('-');
    print_int(whole);
    UART0_Transmitter('.');
    UART0_Transmitter('0'+frac);
}

void print_uint(uint32_t val)
{
    char buf[12]; int i=0;
    if(val==0){UART0_Transmitter('0');return;}
    while(val>0){buf[i++]='0'+(val%10);val/=10;}
    while(i>0)UART0_Transmitter(buf[--i]);
}
