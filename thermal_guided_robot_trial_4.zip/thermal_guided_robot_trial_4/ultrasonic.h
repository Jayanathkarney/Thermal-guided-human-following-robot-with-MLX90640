#ifndef ULTRASONIC_H
#define ULTRASONIC_H

#include <stdint.h>

void     ultrasonic_init(void);
uint32_t ultrasonic_read(void);

#endif
